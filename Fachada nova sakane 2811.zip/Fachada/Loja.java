package Fachada;

package fachada;

import CadastroProduto.*;
import ContasCliente.*;

import Excecoes.*;
import Excecoes.NumeroCadastroExcedidoException;
import ExcecoesProduto.NumeroLimiteExcedido;
import ExcecoesProduto.ProdutoJaCadastrado;
import ExcecoesProduto.ProdutoNaoCadastrado;
import ExcecoesProduto.ProdutoNaoEncontrado;
import Produtos.ClasseProduto;
import Produtos.RepositorioProdutoLista;
import Repositorios.*;
import cadastro.CadastroClientes;

public class Loja {
	CadastroClientes pessoa;
	CadastroProduto produtos;

	public Loja(boolean repositorio) {
		if (repositorio) {
			this.pessoa = new CadastroClientes (new RepositorioContasLista());
			this.produtos = new CadastroProduto (new RepositorioProdutoLista());
		} else {
			
		}
	}
	
	// clientes 
	public void cadastroPessoas (ContaAbstrata conta) throws CpfCadastradoException, NumeroCadastroExcedidoException {
		if (!pessoa.existe(conta.getCpf())) {
			pessoa.cadastrar(conta);
		} else {
			throw new CpfCadastradoException();
		}
	}
	
	public void removerPessoa (String cpf) throws CpfNaoCadastradoException{
		if (pessoa.existe(cpf)) {
			pessoa.remover(cpf);
		} else {
			throw new CpfNaoCadastradoException();
		}
	}
	
	public ContaAbstrata procurarPessoa (String cpf) throws CpfNaoCadastradoException {
		if (pessoa.existe(cpf)) {
			return pessoa.procurar(cpf);
		} else {
			throw new CpfNaoCadastradoException();
		}
	}
	
	public void atualizarPessoa (ContaAbstrata conta) throws CpfNaoCadastradoException {
		if (pessoa.existe(conta.getCpf())) {
			pessoa.atualizar(conta);
		} else {
			throw new CpfNaoCadastradoException();
		}
	}
	
	public boolean existePessoa (String cpf) throws CpfNaoCadastradoException {
		if (pessoa.existe(cpf)) {
			return true;
		} else {
			throw new CpfNaoCadastradoException();
		}
	}
	
	// produto
	public void cadastrarProduto(ClasseProduto ContaProduto) throws NumeroLimiteExcedido, ProdutoJaCadastrado {
		if (!produtos.existe(ContaProduto.getNome())) {
			produtos.cadastrar(ContaProduto);
		} else {
			throw new ProdutoJaCadastrado();
		}
	}

	public void removerProduto(String nomeProduto) throws ProdutoNaoCadastrado {
		if (produtos.existe(nomeProduto)) {
			produtos.remover(nomeProduto);
		} else {
			throw new ProdutoNaoCadastrado();
		}
	}

	public boolean existeProduto(String nomeProduto) {
		if (produtos.existe(nomeProduto)) {
			return true;
		} else {
			return false;
		}
	}

	public ClasseProduto procurarProduto(String nomeProduto) throws ProdutoNaoEncontrado {
		if (produtos.existe(nomeProduto)) {
			return produtos.procurar(nomeProduto);
		} else {
			throw new ProdutoNaoEncontrado();
		}
	}

	public void atualizarProduto(ClasseProduto ContaProduto) throws ProdutoNaoEncontrado {
		if (produtos.existe(ContaProduto.getNome())) {
			produtos.atualizar(ContaProduto);
		} else {
			throw new ProdutoNaoEncontrado();
		}
	}
	// franquia
	
	
}
